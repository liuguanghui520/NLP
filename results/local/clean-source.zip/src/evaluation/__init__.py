"""Integrity checks and metrics."""
