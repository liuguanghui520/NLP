"""Unified sentiment project."""
