# RTX4060跨机复现差异诊断

这不是新的课程提交包，也不是已通过的模型修复。它用于定位环境通过、模型完整执行但输出不一致的问题。只使用验证集，不重新训练、不覆盖正式结果。

## 在4060电脑运行

1. 在WSL原生目录新建空文件夹并解压本诊断包。
2. 激活上次已经通过预检的环境；不重新安装或更换依赖。按回传报告，本机环境为：

```bash
source /home/yilin/.venvs/nlp-course-repro-20261030-02/bin/activate
```

3. 在本诊断包解压根目录运行（输出目录必须尚不存在，已有时换一个新名称）：

```bash
python diagnose_gpu.py --work-root /home/yilin/nlp-course-repro-20261030/model-reproduction-001 --output /home/yilin/nlp-course-repro-20261030/gpu-diagnostic-001 --reference reference-4070 --profiles original controlled_flash controlled_math
```

`--work-root`指向上次完成11次预测的工作目录，其中应存在`configs/paths.local.json`、`data/processed/v1-20261023/`、`artifacts/`和`src/`。若自己的路径不同，只调整路径；无需重跑11次预测，也不把新的诊断结果写入该目录。

## 运行内容

三个配置各在独立子进程加载同一个原始Qwen3-1.7B，固定8条验证样本，零样本和四样本各预测一次，共16条／配置、总计48条。

- original：原BF16／SDPA／贪心路径，继承并记录原环境设置。
- controlled_flash：BF16权重、固定Flash SDPA，关闭低精度归约并开启确定性及固定cuBLAS workspace。
- controlled_math：BF16权重、固定Math SDPA，其余受控设置同上。

后两项是明确的诊断干预，不是正式推理配置，不承诺能让历史主结果完全一致。工具不加载LoRA适配器；先定位原始Qwen零／少样本的主要差异，后续再按证据决定LoRA检查。首次模型加载可能较慢，查看对应配置log可确认进度。出现OOM或配置不支持时保留失败日志，不自行换精度或删失败结果。

## 回传内容

把整个`gpu-diagnostic-001`输出目录压缩回传。包含三个配置的JSON、日志、总体状态和`cross-gpu-comparison.json`。不必回传模型、数据、原环境和缓存。比较结果只属于小规模验证诊断，不能作为正式全量复现通过证明。

对照首先检查输入ID、模型文件身份和数值buffer，再看首步分数、首次生成分歧和受控配置的效果。差异仍存在时继续定位，不自行放宽1e-12门槛或改参考分数。

本包4070对照在用户停止游戏后重新生成，三配置各16条已完整完成；此前受干扰的运行单独保留。每个子进程默认限时600秒，超时返回124并保留日志。运行期间请关闭游戏和其他使用GPU的模型任务。
