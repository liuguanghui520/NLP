"""Integrity checks and metrics."""
