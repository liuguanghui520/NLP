"""Unified sentiment project."""
