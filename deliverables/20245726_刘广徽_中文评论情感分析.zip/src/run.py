"""One command entry for saved-result or real-model reproduction."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'project'))
from submission_reproduce import main
if __name__=='__main__':
    raise SystemExit(main())
